React.render(
  React.createElement("h1", null, "hello word!"),
  document.querySelector('body')
);
