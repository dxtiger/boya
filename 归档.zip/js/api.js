/*

音乐播放器开放方法：
1、隐藏 top.MContral.hide()
2、显示mini播放器  top.MContral.show()
3、显示全屏播放器 top.MContral.show(1)


播放音乐
top.__M.getMusic(item_id,yn,a,s); // item_id : 音频id， yn是否一下首， a = album_id， s = subject_id

top.__M.getId(); // 获取当前音乐item_id；


内页需要调用的js方法
高度变化后，需要调用： top.setFrame(document.body.clientHeight);

*/